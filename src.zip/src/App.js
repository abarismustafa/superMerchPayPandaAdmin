
import { Route, Routes } from 'react-router-dom';
import './assets/css/style.css'
import DasBoardPage from './pages/dasBoardPage';
import DasBoardRight from './pages/dasBoardRight/DasBoardRight';
import Link from './components/link/Link';


function App() {
  return (
    <>
      <Routes>
        <Route path='/admin' element={<DasBoardPage />} >
          <Route path='' element={<DasBoardRight />} />
          <Route path='link' element={<Link />} />
        </Route>

      </Routes>
    </>
  );
}

export default App;
