

const requestMiddleWare = (config) => {
    console.log(config);

}


const responseMiddleWare = (response) => {

}


const errorHandlerMiddleWare = (error) => {

}



export { requestMiddleWare, responseMiddleWare, errorHandlerMiddleWare }