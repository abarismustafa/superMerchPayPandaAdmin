import React from 'react'
import MyCommisionAside from './myCommisionAside/MyCommisionAside'

function MyRechargeCommision() {
  return (
    <section>
      <div className='container'>
        <div className='row'>
            <MyCommisionAside/>
        </div>
      </div>
    </section>
  )
}

export default MyRechargeCommision
