import ApiMasterList from "./apiMasterList/ApiMasterList"

function ApiMaster() {
    return (
        <>
            <ApiMasterList />
        </>
    )
}
export default ApiMaster