import ApiVandorPaymentList from "./apiVandorPaymentList/ApiVandorPaymentList"

function ApiVandorPayment() {
    return (
        <>
            <ApiVandorPaymentList />
        </>
    )
}
export default ApiVandorPayment