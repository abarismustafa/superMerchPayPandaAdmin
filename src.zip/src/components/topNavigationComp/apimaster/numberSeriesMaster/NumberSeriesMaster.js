import NumberSeriesMasterList from "./numberSeriesMasterList/NumberSeriesMasterList"

function NumberSeriesMaster() {
    return (
        <>
            <NumberSeriesMasterList />
        </>
    )
}
export default NumberSeriesMaster