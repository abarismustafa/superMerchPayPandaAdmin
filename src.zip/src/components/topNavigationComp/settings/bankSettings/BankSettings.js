import BankSettingsList from "./bankSettingsList/BankSettingsList"

function BankSettings() {
    return (
        <>
            <BankSettingsList />
        </>
    )
}
export default BankSettings