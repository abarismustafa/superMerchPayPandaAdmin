import SmsSettingsList from "./smsSettingsList/SmsSettingList"

function SmsSettings() {
    return (
        <>
            <SmsSettingsList />
        </>
    )
}
export default SmsSettings