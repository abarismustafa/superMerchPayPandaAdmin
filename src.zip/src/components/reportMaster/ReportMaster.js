import React from 'react'
import AlltransationsReport from './alltransationsReports/AlltransationsReport'

function ReportMaster() {
    return (
        <section>
            <div className='main-content-body'>
                    <AlltransationsReport />
            </div>
        </section>
    )
}

export default ReportMaster
