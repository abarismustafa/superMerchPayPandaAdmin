import RetailerIncone from "../../components/retailerIncome/RetailerIncome"

function RetailerIncomePage() {
    return (
        <>
            <RetailerIncone />
        </>
    )
}
export default RetailerIncomePage