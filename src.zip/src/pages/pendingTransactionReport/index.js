import React from 'react'
import PendingTransactionReport from '../../components/reportMaster/pendingTransactionReport/PendingTransactionReport'

function PendingTransactionReportPage() {
  return (
    <>
      <PendingTransactionReport/>
    </>
  )
}

export default PendingTransactionReportPage
