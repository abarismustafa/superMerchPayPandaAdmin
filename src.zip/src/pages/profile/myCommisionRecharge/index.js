import React from 'react'
import MyRechargeCommision from '../../../components/profile/myRechargeCommisionMain/myRechargeCommision/MyRechargeCommision'

function MyCommissionRechargePage() {
  return (
    <>
      <MyRechargeCommision/>
    </>
  )
}

export default MyCommissionRechargePage
