import BalanceTransfer from "../../components/balanceTransfer/BalanceTransfer"

function BalanceTransferPage() {
    return (
        <>
            <BalanceTransfer />
        </>
    )
}
export default BalanceTransferPage