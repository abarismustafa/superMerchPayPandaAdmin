import PaymentRequest from "../../components/PaymentRequest/PaymentRequest"

function PaymentRequestPage() {
    return (
        <>
            <PaymentRequest />
        </>
    )
}
export default PaymentRequestPage