import DistributerIncome from "../../components/distributerIncome/DistributerIncome"

function DistributerIncomePage() {
    return (
        <>
            <DistributerIncome />
        </>
    )
}
export default DistributerIncomePage