import BalanceReturnRequest from "../../components/balanceReturnRequest/BalanceReturnRequest"

function BalanceReturnRequestPage() {
    return (
        <>
            <BalanceReturnRequest />
        </>
    )
}
export default BalanceReturnRequestPage