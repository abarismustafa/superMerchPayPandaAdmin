import PendingDisput from "../../components/pendingDisput/PendingDisput"

function PendingDisputPage() {
    return (
        <>
            <PendingDisput />
        </>
    )
}
export default PendingDisputPage