import ServiceBanner from "../../../../components/topNavigationComp/settings/serviceBanner/ServiceBanner"

function ServiceBannerPage() {
    return (
        <>
            <ServiceBanner />
        </>
    )
}
export default ServiceBannerPage