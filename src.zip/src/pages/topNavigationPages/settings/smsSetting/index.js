import SmsSettings from "../../../../components/topNavigationComp/settings/smsSetting/SmsSettings"

function SmsSettingsPage() {
    return (
        <>
            <SmsSettings />
        </>
    )
}
export default SmsSettingsPage