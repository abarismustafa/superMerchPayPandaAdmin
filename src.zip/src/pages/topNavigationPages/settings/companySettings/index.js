import React from 'react'
import { CompanySettings } from "../../../../components/topNavigationComp/settings/companySetting/CompanySettings";
function CompanySettings() {
  return (
    <>
      <CompanySettings/>
    </>
  )
}

export default CompanySettings
