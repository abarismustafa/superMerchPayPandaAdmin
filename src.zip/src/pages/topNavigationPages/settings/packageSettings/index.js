import PackageSettings from "../../../../components/topNavigationComp/settings/packageSettings/PackageSettings"

function PackageSettingsPage() {
    return (
        <>
            <PackageSettings />
        </>
    )
}
export default PackageSettingsPage