import SignatureUpload from "../../../../components/topNavigationComp/settings/signatureUpload/SignatureUpload"

function SignatureUploadPage() {
    return (
        <>
            <SignatureUpload />
        </>
    )
}
export default SignatureUploadPage