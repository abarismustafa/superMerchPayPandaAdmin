import BankSettings from "../../../../components/topNavigationComp/settings/bankSettings/BankSettings"

function BankSettingsPage() {
    return (
        <>
            <BankSettings />
        </>
    )
}
export default BankSettingsPage