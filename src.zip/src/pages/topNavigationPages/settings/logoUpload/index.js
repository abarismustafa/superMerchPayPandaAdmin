import LogoUpload from "../../../../components/topNavigationComp/settings/logoUpload/LogoUpload"

function LogoUploadPage() {
    return (
        <>
            <LogoUpload />
        </>
    )
}
export default LogoUploadPage