import Dynemic from "../../../../components/topNavigationComp/websiteMaster/dynemicPage/Dynemic"

function DynemicPage() {
    return (
        <>
            <Dynemic />
        </>
    )
}
export default DynemicPage