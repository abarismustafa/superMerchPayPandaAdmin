import FrontBanner from "../../../../components/topNavigationComp/websiteMaster/frontBanner/FrontBanner"

function FrontBannerPage() {
    return (
        <>
            <FrontBanner />
        </>
    )
}
export default FrontBannerPage