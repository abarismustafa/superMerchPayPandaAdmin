import Country from "../../../../components/topNavigationComp/ZoneModule/country/Country"

function CountryPage() {
    return (
        <>
            <Country />
        </>
    )
}
export default CountryPage