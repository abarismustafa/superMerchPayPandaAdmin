import AgentOnbording from "../../../components/topNavigationComp/masters/agentOnbording/AgentOnbording"

function AgentOnbordingPage() {
    return (
        <>
            <AgentOnbording />
        </>
    )
}
export default AgentOnbordingPage