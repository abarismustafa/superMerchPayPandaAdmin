import ApiMaster from "../../../../components/topNavigationComp/apimaster/appiMaster/ApiMaster"

function ApiMasterPage() {
    return (
        <>
            <ApiMaster />
        </>
    )
}
export default ApiMasterPage