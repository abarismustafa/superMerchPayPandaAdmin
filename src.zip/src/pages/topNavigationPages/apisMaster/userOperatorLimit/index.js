import UserOperatorLimit from "../../../../components/topNavigationComp/apimaster/userOperatorLimit/UserOperatorLimit"

function UserOperatorLimitPage() {
    return (
        <>
            <UserOperatorLimit />
        </>
    )
}
export default UserOperatorLimitPage