import ApiVandorPayment from "../../../../components/topNavigationComp/apimaster/apiVandorPayment/ApiVandorPayment"

function ApiVandorPaymentPage() {
    return (
        <>
            <ApiVandorPayment />
        </>
    )
}
export default ApiVandorPaymentPage