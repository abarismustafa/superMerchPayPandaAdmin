import BackupApiMaster from "../../../../components/topNavigationComp/apimaster/backupApiMaster/BackupApiMaster"

function BackupApiMasterPage() {
    return (
        <>
            <BackupApiMaster />
        </>
    )
}
export default BackupApiMasterPage