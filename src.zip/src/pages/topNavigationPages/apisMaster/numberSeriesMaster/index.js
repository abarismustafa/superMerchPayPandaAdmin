import NumberSeriesMaster from "../../../../components/topNavigationComp/apimaster/numberSeriesMaster/NumberSeriesMaster"

function NumberSeriesMasterPage() {
    return (
        <>
            <NumberSeriesMaster />
        </>
    )
}
export default NumberSeriesMasterPage