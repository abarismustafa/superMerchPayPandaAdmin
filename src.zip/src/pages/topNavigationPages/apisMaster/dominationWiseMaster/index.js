import DominationWiseMaster from "../../../../components/topNavigationComp/apimaster/dominationWiseMaster/DominationWiseMaster"

function DominationWiseMasterPage() {
    return (
        <>
            <DominationWiseMaster />
        </>
    )
}
export default DominationWiseMasterPage