import StateWiseApi from "../../../../components/topNavigationComp/apimaster/stateWiseApi/StateWiseApi"

function StateWiseApiPage() {
    return (
        <>
            <StateWiseApi />
        </>
    )
}
export default StateWiseApiPage