import StatusMaster from "../../../../components/topNavigationComp/masters/statusMaster/StatusMaster"

function StatusMasterPage() {
    return (
        <>
            <StatusMaster />
        </>
    )
}
export default StatusMasterPage