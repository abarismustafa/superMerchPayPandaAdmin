import ServiceMaster from "../../../../components/topNavigationComp/masters/serviceMaster/ServiceMaster"

function ServiceMasterPage() {
    return (
        <>
            <ServiceMaster />
        </>
    )
}
export default ServiceMasterPage