import PaymentMethodMaster from "../../../../components/topNavigationComp/masters/paymentMethodMaster/PaymentMethodMaster"

function PaymentMethodMasterPage() {
    return (
        <>
            <PaymentMethodMaster />
        </>
    )
}
export default PaymentMethodMasterPage