import React from 'react'
import ApiMaster from '../../../components/topNavigationComp/apimaster/ApiMaster'

const Provider = () => {
  return (
    <>
      <ApiMaster/>
    </>
  )
}

export default Provider
