import React from 'react'
import WhatsappRoleWise from '../../../components/topNavigationComp/whatsappRoleWise/WhatsappRoleWise'

const SendRoleWise = () => {
  return (
    <>
      <WhatsappRoleWise/>
    </>
  )
}

export default SendRoleWise
