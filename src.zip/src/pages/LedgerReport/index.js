import React from 'react'
import LedgerReport from '../../components/reportMaster/ledgerReport/LedgerReport'

function LedgerReportPage() {
  return (
    <>
      <LedgerReport/>
    </>
  )
}

export default LedgerReportPage
