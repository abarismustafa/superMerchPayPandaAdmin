import MyIncome from "../../components/myIncome/MyIncome"

function MyIncomePage() {
    return (
        <>
            <MyIncome />
        </>
    )
}
export default MyIncomePage