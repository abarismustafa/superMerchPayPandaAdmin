import Distributer from "../../components/distributer/Distributer"

function DistributerPage() {
    return (
        <>
            <Distributer />
        </>
    )
}
export default DistributerPage