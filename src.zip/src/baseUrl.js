

export const baseUrl = 'https://api.paypandabnk.com/api/'
